cl.exe /c /EHsc Basic_Multi_Shape.c && rc.exe OGL.rc && link.exe Basic_Multi_Shape.obj OGL.res User32.lib GDI32.lib /SUBSYSTEM:WINDOWS && Basic_Multi_Shape.exe

