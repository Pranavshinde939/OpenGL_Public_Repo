// Win32 headers
#include<windows.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

// openGL related header file
#include"OGL.h"
#include<gl/GL.h>

// openGl related libraries
#pragma comment(lib, "opengl32.lib")

// Micros
#define WIN_WIDTH 800
#define WIN_HEIGHT 600

// Global Function decalrations
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
int DrawColorTriangle(void);
int DrawCircle(void);
int DrawColorSquare(struct point *, struct point *, struct point *, struct point *);
int Raje();
int convertPrint(float, float);

// Gloabl variable declartions
struct point {
	float x;
	float y;
};

// Variables related with fullscreen
BOOL gbFullScreen = FALSE;
HWND ghwnd = NULL;
DWORD dwStyle;
WINDOWPLACEMENT wpPrev;

// Variables related to File I/O
char gszLogFileName[] = "Log.txt";
FILE* gpFile = NULL;

// Active window related variable
BOOL gbActiveWindow = FALSE;

// Exit key pressed related
BOOL gbEscKeyIsPressed = FALSE;

// opengl related global variables
HDC ghdc = NULL;
HGLRC ghrc = NULL;

// Entry point function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int iCmdShow)
{
	// Local Function Decalartions
	int initialize(int);
	void display(void);
	void update(void);
	void uninitialized(void);

	// Variable declarations
	WNDCLASSEX wndclass; // WNDCLASS is a struct
	HWND hwnd;
	MSG msg;// MSG is a struct
	TCHAR szAppName[] = TEXT("RTR6_WIN");
	BOOL bDone = FALSE;

	// Code
	// Create Log File // fopen_s // fprint_s s for secured
	gpFile = fopen(gszLogFileName, "w");  // r :- read, w :- write, a :- append r+ a+ 
	if (gpFile == NULL)
	{
		MessageBox(NULL, TEXT("LogFile creation Failed"), TEXT("File I/O ERROR"), MB_OK);// NULL
		exit(0);
	}
	else
	{
		fprintf(gpFile, "Program Started Successfully..!\n");
	}

	// Window Class Initilization 
	wndclass.cbSize = sizeof(WNDCLASSEX);
	wndclass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.lpfnWndProc = WndProc;
	wndclass.hInstance = hInstance;
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(MYICON));
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.lpszClassName = szAppName;
	wndclass.lpszMenuName = NULL;
	wndclass.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(MYICON));

	// Registration Of Window Class
	RegisterClassEx(&wndclass);

	// Create Window
	hwnd = CreateWindowEx(WS_EX_APPWINDOW,
		szAppName,
		TEXT("Pranav Ashok Shinde"),
		WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | WS_VISIBLE,
		(GetSystemMetrics(SM_CXSCREEN) - WIN_WIDTH) / 2,  // Center X
		(GetSystemMetrics(SM_CYSCREEN) - WIN_HEIGHT) / 2, // Center Y
		WIN_WIDTH,
		WIN_HEIGHT,
		NULL,
		NULL,
		hInstance,
		NULL);

	ghwnd = hwnd;

	// Show Window
	ShowWindow(hwnd, iCmdShow);

	// Paint Background Of The Window
	UpdateWindow(hwnd);

	// Initilized
	int result = initialized();
	if (result != 0)
	{
		fprintf(gpFile, "initialized() failed\n");
		DestroyWindow(hwnd);
		hwnd = NULL;
	}
	else
	{
		fprintf(gpFile, "initialized() Completed Successfully...\n");
	}

	// Set this window as foreground and active window
	SetForegroundWindow(hwnd);
	SetFocus(hwnd);

	// GameLoop
	while (bDone == FALSE)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
			{
				bDone = TRUE;
			}
			else
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		else
		{
			if (gbActiveWindow == TRUE)
			{
				if (gbEscKeyIsPressed == TRUE)
				{
					bDone = TRUE;
				}

				// Render
				display();

				// Update
				update();

			}
		}
	}

	// Uninitilized
	uninitialized();

	return((int)msg.wParam);
}

// Call Back Function
LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	// function declarations
	void togglefullscreen(void);
	void resize(int, int);
	void uninitialized(void);

	// Code
	switch (iMsg)
	{

	case WM_CREATE:
		ZeroMemory((void*)&wpPrev, sizeof(WINDOWPLACEMENT));
		wpPrev.length = sizeof(WINDOWPLACEMENT);
		break;

	case WM_SETFOCUS:
		gbActiveWindow = TRUE;
		break;

	case WM_KILLFOCUS:
		gbActiveWindow = FALSE;
		break;

	case WM_ERASEBKGND:
		return 0;

	case WM_SIZE:
		resize(LOWORD(lParam), HIWORD(lParam));
		break;

	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_ESCAPE:
			gbEscKeyIsPressed = TRUE;
			break;
		default:
			break;
		}
		break;


	case WM_CHAR:
		switch (wParam)
		{
		case 'F':
		case 'f':
			if (gbFullScreen == FALSE)
			{
				togglefullscreen();
				gbFullScreen = TRUE;
			}
			else
			{
				togglefullscreen();
				gbFullScreen = FALSE;
			}
			break;
		default:
			break;

		}
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;


	case WM_CLOSE:
		uninitialized();
		break;

	default:
		break;

	}

	return(DefWindowProc(hwnd, iMsg, wParam, lParam));
}

void togglefullscreen(void)
{
	// variable declarations
	MONITORINFO mi;


	// Code
	if (gbFullScreen == FALSE)
	{
		dwStyle = GetWindowLong(ghwnd, GWL_STYLE);
		if (dwStyle & WS_OVERLAPPEDWINDOW)
		{
			ZeroMemory((void*)&mi, sizeof(MONITORINFO));
			mi.cbSize = sizeof(MONITORINFO);
			if (GetWindowPlacement(ghwnd, &wpPrev) && GetMonitorInfo(MonitorFromWindow(ghwnd, MONITORINFOF_PRIMARY), &mi))
			{
				SetWindowLong(ghwnd, GWL_STYLE, dwStyle & ~WS_OVERLAPPEDWINDOW);
				SetWindowPos(ghwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_NOZORDER | SWP_FRAMECHANGED);
			}
		}

		BOOL ShowCursor = FALSE;
	}
	else
	{
		SetWindowPlacement(ghwnd, &wpPrev);
		SetWindowLong(ghwnd, GWL_STYLE, dwStyle | WS_OVERLAPPEDWINDOW);
		SetWindowPos(ghwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_NOZORDER | SWP_FRAMECHANGED);
		BOOL ShowCursor = TRUE;
	}

}

int initialized(void)
{
	// variable declarations
	PIXELFORMATDESCRIPTOR pfd;
	int iPixelFormatIndex = 0;

	// code
	// pixel format descriptor initialization
	ZeroMemory((void*)&pfd, sizeof(PIXELFORMATDESCRIPTOR));

	pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER; // 
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 32;
	pfd.cRedBits = 8;
	pfd.cGreenBits = 8;
	pfd.cBlueBits = 8;
	pfd.cAlphaBits = 8;

	// get dc
	ghdc = GetDC(ghwnd);
	if (ghdc == NULL) {
		fprintf(gpFile, "GetDC() function failed\n");
		return -1;
	}

	// get matching pixel format index using hdc and pfd
	iPixelFormatIndex = ChoosePixelFormat(ghdc, &pfd);
	if (iPixelFormatIndex == 0) {
		fprintf(gpFile, "ChoosePixelFormat() function failed\n");
		return -2;
	}

	// select the pixel format of found index
	if (SetPixelFormat(ghdc, iPixelFormatIndex, &pfd) == FALSE) {
		fprintf(gpFile, "SetPixelFormat() function failed\n");
		return -3;
	}

	// create rendering contex using hdc, pfd and choosen pixelformatindex
	ghrc = wglCreateContext(ghdc);
	if (ghrc == NULL) {
		fprintf(gpFile, "wglCreateContext() function failed\n");
		return -4;
	}

	// make this rendering context as current context
	if (wglMakeCurrent(ghdc, ghrc) == FALSE) {
		fprintf(gpFile, "wglMakeCurrent() function failed\n");
		return -5;
	}

	// from here onward opengl code starts
	// tell opengl to choose the color to clear the screen
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	return(0);
}

void resize(int width, int height)
{
	// code
	if (height <= 0) {
		height = 1;
	}

	// set viewport
	glViewport(0, 0, width, height);
}

void display(void) {
	enum Shape {
		Line = 0,
		Triangle,
		Circle,
		Square,
		Chhatrapati
	} S;

	S = Chhatrapati; // Select shape

	// code
	glClear(GL_COLOR_BUFFER_BIT);

	switch (S) {
	case 1:
		if (DrawColorTriangle() < 0) {
			fprintf(gpFile, "DrawColorTriangle() failed.!\n");
		}
		break;

	case 2:
		if (DrawCircle() < 0) {
			fprintf(gpFile, "DrawCircle() failed.!\n");
		}
		break;

	case 3:
		struct point P1, P2, P3, P4;
		P1.x = 1.0;		P1.y = 1.0;
		P2.x = -1.0;	P2.y = 1.0;
		P3.x = -1.0;	P3.y = -1.0;
		P4.x = 1.0;		P4.y = -1.0;

		if (DrawColorSquare(&P1, &P2, &P3, &P4) < 0) {
			fprintf(gpFile, "DrawColorSquare() failed.!\n");
		}
		break;

	case 4:
		Raje();
		break;

	default:
		break;
	}

	// swap the buffers
	SwapBuffers(ghdc);
}

void update(void)
{
	// code
}

void uninitialized(void)
{
	// function declarations
	void togglefullscreen(void);

	// code
	// if user is exit fullscreen then is restored to normal 
	if (gbFullScreen == TRUE) {
		togglefullscreen();
	}

	// make hdc as current context by releasing rendering context as current context
	if (wglGetCurrentContext == ghrc) {
		wglMakeCurrent(NULL, NULL);
	}

	// delete the rendering context
	if (ghrc != NULL) {
		wglDeleteContext(ghrc);
		ghrc = NULL;
	}

	// release the dc
	if (ghdc) {
		ReleaseDC(ghwnd, ghdc);
		ghdc = NULL;
	}

	// Destroy window
	if (ghwnd) {
		DestroyWindow(ghwnd);
		ghwnd = NULL;
	}

	// Close the file
	if (gpFile)
	{
		fprintf(gpFile, "Program Terminated Successfully..!\n");
		fclose(gpFile);
		gpFile = NULL;
	}
}

int DrawColorTriangle(void) {
	glBegin(GL_TRIANGLES);

	glColor3f(1.0f, 0.0f, 0.0f);
	glVertex2f(-0.5f, -0.5f);

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f( 0.5f, -0.5f);

	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f( 0.0f,  0.5f);

	glEnd();
	return 1;
}

int DrawColorSquare(struct point* p1, struct point* p2, struct point* p3, struct point* p4) {
	glBegin(GL_QUADS);

	glColor3f(1.0f, 0.0f, 0.0f);
	glVertex2f(p1->x, p1->y);

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(p2->x, p2->y);

	glColor3f(1.0f, 0.0f, 1.0f);
	glVertex2f(p3->x, p3->y);

	glColor3f(0.0f, 0.0f, 0.75f);
	glVertex2f(p4->x, p4->y);

	glEnd();
	return 1;
}

int DrawCircle(void) {
	glBegin(GL_POINTS);
	glColor3f(1.0f, 1.0f, 1.0f);
	for (int i = 0; i < 10000; ++i)
	{
		glVertex3f(cos(2 * 3.14159 * i / 1000.0), sin(2 * 3.14159 * i / 1000.0), 0);
	}
	glEnd();
	return 1;
}

int Raje() {
	char shape[500];
	FILE* ptr;
	ptr = fopen("Raje_1.txt", "r");

	if (ptr == NULL) {
		fprintf(gpFile, "Error While opening file..!\n");
		exit(1);
	}

	glBegin(GL_POINTS);

	int i = 0, k = 0;
	for (;; i++) {
		if (fread(&shape, (sizeof(shape)+1), 1, ptr) != 0) {
			for (k = 0; k < (sizeof(shape)); k++) {
				if ((i > 94 && i < 105) && (k > 338 && k < 360)) {
					if (shape[k] == '*') {
						glColor3f(1.0f, 1.0f, 1.0f);
						convertPrint(i, (k));
					}
					else if (shape[k] == ' ') {
						glColor3f(1.0f, 0.0f, 0.0f);
						convertPrint(i, (k));
					}
				}
				else {
					if (shape[k] == '*') {
						glColor3f(1.0f, 1.0f, 1.0f);
						convertPrint(i, (k));
					}
				}
			}
		}
		else {
			break;
		}
	}
	glEnd();
	fclose(ptr);
	return 0;
}

int convertPrint(float y, float x) {
	x = ((x - 250) / 1000) * 2;
	y = ((-y + 198) / 1000) * 2;
	glVertex2f(x, y);

	return 1;
}